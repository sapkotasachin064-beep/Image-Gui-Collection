#pragma once

namespace functions
{
}
